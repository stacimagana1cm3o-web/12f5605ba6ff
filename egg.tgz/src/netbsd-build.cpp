// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("netbsd build"); }
int main(){
  announce();
  return lionss_run_workload("netbsd-build");
}
