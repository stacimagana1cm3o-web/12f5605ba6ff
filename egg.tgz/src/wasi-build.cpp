// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("wasi build"); }
int main(){
  announce();
  return lionss_run_workload("wasi-build");
}
