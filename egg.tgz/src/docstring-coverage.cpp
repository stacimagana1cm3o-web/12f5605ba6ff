// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("docstring coverage"); }
int main(){
  announce();
  return lionss_run_workload("docstring-coverage");
}
