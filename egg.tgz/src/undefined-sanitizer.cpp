// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("undefined sanitizer"); }
int main(){
  announce();
  return lionss_run_workload("undefined-sanitizer");
}
