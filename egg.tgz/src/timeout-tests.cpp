// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("timeout tests"); }
int main(){
  announce();
  return lionss_run_workload("timeout-tests");
}
